# Data Cleaning & Structural Validation — Task 1

Transform raw, unstructured data into a reliable format for analysis.

---

## Project Structure

```
data_cleaning_project/
├── data_cleaning.py   ← main pipeline script
├── raw_data.csv       ← input dataset (12 raw records)
├── requirements.txt   ← Python dependencies
└── README.md
```

After running, two files are generated:
- `clean_data.csv` — validated, clean output
- `cleaning_log.txt` — full step-by-step log

---

## Setup in VS Code

### 1. Open the folder
```
File → Open Folder → select data_cleaning_project
```

### 2. Create a virtual environment (recommended)
```bash
python -m venv venv
```
Activate it:
- **Windows:** `venv\Scripts\activate`
- **Mac/Linux:** `source venv/bin/activate`

### 3. Install dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the pipeline
```bash
python data_cleaning.py
```

---

## Pipeline Steps

| Step | What it does |
|------|-------------|
| 1 — Duplicates | Drops exact duplicate rows and duplicate IDs (keeps first) |
| 2 — Missing values | Replaces placeholders (—, -, N/A) with NaN; drops rows missing critical fields |
| 3 — Format normalization | Standardizes dates to ISO 8601, title-cases names, lowercases status, validates email regex |
| 4 — Type validation | Coerces amount to float, ID to int, enforces status domain {paid, pending, refunded, cancelled} |
| 5 — Report | Prints summary stats and saves full log |

---

## Expected Output

```
================================================
  Data Cleaning & Structural Validation
================================================
[LOAD] Loaded 12 rows from 'raw_data.csv'
[DUPLICATES] Removed 3 exact duplicate row(s)
[MISSING] Column 'name' has 1 null value(s)
...

╔══════════════════════════════════════════════╗
║       DATA CLEANING REPORT — TASK 1         ║
╚══════════════════════════════════════════════╝

  Raw rows          : 12
  Clean rows        : 9
  Rows removed      : 3
  Remaining NULLs   : 5
  Completeness      : 94.4%
```
