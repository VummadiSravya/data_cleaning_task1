"""
Data Cleaning & Structural Validation Pipeline
Task 1 — Transform raw, unstructured data into a reliable format for analysis.
"""

import pandas as pd
import numpy as np
import re
import os
from datetime import datetime

# ──────────────────────────────────────────────
# CONFIG
# ──────────────────────────────────────────────
INPUT_FILE  = "raw_data.csv"
OUTPUT_FILE = "clean_data.csv"
LOG_FILE    = "cleaning_log.txt"

ALLOWED_STATUSES = {"paid", "pending", "refunded", "cancelled"}
EMAIL_PATTERN    = re.compile(r"^[\w.+\-]+@[\w\-]+\.\w+$")

PLACEHOLDERS = ["—", "-", "", " ", "N/A", "n/a", "null", "NULL", "None"]

# ──────────────────────────────────────────────
# LOGGING UTILITY
# ──────────────────────────────────────────────
log_entries = []

def log(step: str, message: str):
    entry = f"[{step}] {message}"
    print(entry)
    log_entries.append(entry)


# ──────────────────────────────────────────────
# STEP 0 — LOAD RAW DATA
# ──────────────────────────────────────────────
def load_data(filepath: str) -> pd.DataFrame:
    df = pd.read_csv(filepath, dtype=str)
    log("LOAD", f"Loaded {len(df)} rows from '{filepath}'")
    log("LOAD", f"Columns: {list(df.columns)}")
    return df


# ──────────────────────────────────────────────
# STEP 1 — REMOVE DUPLICATES
# ──────────────────────────────────────────────
def remove_duplicates(df: pd.DataFrame) -> pd.DataFrame:
    before = len(df)

    # Exact duplicate rows
    df = df.drop_duplicates(keep="first")
    exact_removed = before - len(df)
    if exact_removed:
        log("DUPLICATES", f"Removed {exact_removed} exact duplicate row(s)")

    # Duplicate primary keys (keep first occurrence)
    key_before = len(df)
    df = df.drop_duplicates(subset=["id"], keep="first")
    key_removed = key_before - len(df)
    if key_removed:
        log("DUPLICATES", f"Removed {key_removed} duplicate ID(s) — kept first occurrence")

    total_removed = before - len(df)
    log("DUPLICATES", f"Total removed: {total_removed} | Rows remaining: {len(df)}")
    return df.reset_index(drop=True)


# ──────────────────────────────────────────────
# STEP 2 — HANDLE MISSING VALUES
# ──────────────────────────────────────────────
def handle_missing(df: pd.DataFrame) -> pd.DataFrame:
    # Replace all placeholder strings with NaN
    df.replace(PLACEHOLDERS, np.nan, inplace=True)

    null_counts = df.isnull().sum()
    for col, cnt in null_counts.items():
        if cnt:
            log("MISSING", f"Column '{col}' has {cnt} null value(s)")

    # Drop rows where critical identity fields are missing
    critical = ["id", "date"]
    before = len(df)
    df.dropna(subset=critical, inplace=True)
    dropped = before - len(df)
    if dropped:
        log("MISSING", f"Dropped {dropped} row(s) missing critical fields {critical}")
    else:
        log("MISSING", "No rows dropped — all critical fields present")

    return df.reset_index(drop=True)


# ──────────────────────────────────────────────
# STEP 3 — FORMAT NORMALIZATION
# ──────────────────────────────────────────────
def normalize_formats(df: pd.DataFrame) -> pd.DataFrame:
    # --- Dates ->  ISO 8601 (YYYY-MM-DD) ---
    original_dates = df["date"].copy()
    df["date"] = pd.to_datetime(df["date"], dayfirst=False, errors="coerce")

    bad_dates = df[df["date"].isnull() & original_dates.notnull()]
    for idx, row in bad_dates.iterrows():
        log("FORMAT", f"Row {idx} (ID {row['id']}): unparseable date '{original_dates[idx]}' ->  NULL")

    df["date"] = df["date"].dt.strftime("%Y-%m-%d")

    # --- Name ->  Title Case ---
    if "name" in df.columns:
        df["name"] = df["name"].str.strip().str.title()

    # --- Status ->  lowercase ---
    if "status" in df.columns:
        df["status"] = df["status"].str.strip().str.lower()

    # --- Email ->  validate format ---
    def validate_email(email):
        if pd.isna(email):
            return np.nan
        email = email.strip()
        return email if EMAIL_PATTERN.match(email) else np.nan

    original_emails = df["email"].copy()
    df["email"] = df["email"].apply(validate_email)

    invalid_emails = df[df["email"].isnull() & original_emails.notnull()]
    for idx, row in invalid_emails.iterrows():
        log("FORMAT", f"Row {idx} (ID {row['id']}): invalid email '{original_emails[idx]}' ->  NULL")

    log("FORMAT", "Normalization complete — dates, casing, email validation applied")
    return df


# ──────────────────────────────────────────────
# STEP 4 — TYPE COERCION & DOMAIN VALIDATION
# ──────────────────────────────────────────────
def validate_types(df: pd.DataFrame) -> pd.DataFrame:
    # --- ID ->  integer ---
    df["id"] = pd.to_numeric(df["id"], errors="coerce").astype("Int64")

    # --- Amount ->  float; non-numeric ->  NaN ---
    original_amounts = df["amount"].copy()
    df["amount"] = pd.to_numeric(df["amount"], errors="coerce")

    invalid_amounts = df[df["amount"].isnull() & original_amounts.notnull()]
    for idx, row in invalid_amounts.iterrows():
        log("TYPES", f"Row {idx} (ID {row['id']}): non-numeric amount '{original_amounts[idx]}' ->  NULL")

    # No negative amounts allowed
    neg_mask = df["amount"] < 0
    if neg_mask.any():
        log("TYPES", f"Found {neg_mask.sum()} negative amount(s) ->  set to NULL")
        df.loc[neg_mask, "amount"] = np.nan

    # --- Status ->  domain validation ---
    invalid_status = df["status"].notna() & ~df["status"].isin(ALLOWED_STATUSES)
    for idx, row in df[invalid_status].iterrows():
        log("TYPES", f"Row {idx} (ID {row['id']}): invalid status '{row['status']}' ->  NULL")
    df.loc[invalid_status, "status"] = np.nan

    log("TYPES", f"Type coercion complete. Null summary:\n{df.isnull().sum().to_string()}")
    return df


# ──────────────────────────────────────────────
# STEP 5 — GENERATE CLEANING REPORT
# ──────────────────────────────────────────────
def generate_report(raw_df: pd.DataFrame, clean_df: pd.DataFrame):
    total_raw    = len(raw_df)
    total_clean  = len(clean_df)
    removed      = total_raw - total_clean
    null_cells   = int(clean_df.isnull().sum().sum())
    total_cells  = clean_df.size
    completeness = round((1 - null_cells / total_cells) * 100, 1)

    report = (
        "\n" + "=" * 48 + "\n" +
        "  DATA CLEANING REPORT - TASK 1\n" +
        "=" * 48 + "\n" +
        f"  Raw rows          : {total_raw}\n" +
        f"  Clean rows        : {total_clean}\n" +
        f"  Rows removed      : {removed}\n" +
        f"  Remaining NULLs   : {null_cells}\n" +
        f"  Completeness      : {completeness}%\n\n" +
        f"  Output saved to   : {OUTPUT_FILE}\n" +
        f"  Log saved to      : {LOG_FILE}\n" +
        "=" * 48 + "\n"
    )
    print(report)
    log_entries.append(report)


# ──────────────────────────────────────────────
# MAIN PIPELINE
# ──────────────────────────────────────────────
def run_pipeline():
    print("=" * 48)
    print("  Data Cleaning & Structural Validation")
    print("=" * 48)

    # Load
    raw_df = load_data(INPUT_FILE)
    raw_snapshot = raw_df.copy()

    # Pipeline steps
    df = remove_duplicates(raw_df)
    df = handle_missing(df)
    df = normalize_formats(df)
    df = validate_types(df)

    # Save clean data
    df.to_csv(OUTPUT_FILE, index=False)
    log("SAVE", f"Clean data written to '{OUTPUT_FILE}'")

    # Report
    generate_report(raw_snapshot, df)

    # Save log
    with open(LOG_FILE, "w", encoding="utf-8") as f:
        f.write(f"Run timestamp: {datetime.now().isoformat()}\n\n")
        f.write("\n".join(log_entries))
    print(f"  Log written to '{LOG_FILE}'")


if __name__ == "__main__":
    run_pipeline()
